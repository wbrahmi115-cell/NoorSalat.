package com.noorsalat.app

import android.content.Context
import android.content.SharedPreferences

/** حفظ إعدادات المستخدم محليًا على الهاتف (SharedPreferences). */
class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("noor_prefs", Context.MODE_PRIVATE)

    var cityId: String
        get() = sp.getString("city_id", Cities.DEFAULT_ID) ?: Cities.DEFAULT_ID
        set(v) { sp.edit().putString("city_id", v).apply() }

    var methodId: String
        get() = sp.getString("method_id", Methods.DEFAULT_ID) ?: Methods.DEFAULT_ID
        set(v) { sp.edit().putString("method_id", v).apply() }

    /** العصر بالمذهب الحنفي (ظل = مثلان). الافتراضي: المثل (المالكي/الشافعي/الحنبلي). */
    var hanafi: Boolean
        get() = sp.getBoolean("hanafi", false)
        set(v) { sp.edit().putBoolean("hanafi", v).apply() }

    /** دقائق التنبيه قبل الصلاة (0 = معطّل). */
    var preMinutes: Int
        get() = sp.getInt("pre_minutes", 10)
        set(v) { sp.edit().putInt("pre_minutes", v).apply() }

    /** إشعار عند دخول الوقت حتى لو كان الأذان معطّلًا لتلك الصلاة. */
    var notifyAtTime: Boolean
        get() = sp.getBoolean("notify_at_time", true)
        set(v) { sp.edit().putBoolean("notify_at_time", v).apply() }

    /** استخدام AlarmClock: الأدق والأضمن في وضع النوم (Doze) لكنه يُظهر أيقونة منبه. */
    var useAlarmClock: Boolean
        get() = sp.getBoolean("use_alarm_clock", true)
        set(v) { sp.edit().putBoolean("use_alarm_clock", v).apply() }

    /** قناة الصوت: "alarm" (صوت المنبه) أو "media" (صوت الوسائط). */
    var audioStream: String
        get() = sp.getString("audio_stream", "alarm") ?: "alarm"
        set(v) { sp.edit().putString("audio_stream", v).apply() }

    var hijriAdjust: Int
        get() = sp.getInt("hijri_adjust", 0)
        set(v) { sp.edit().putInt("hijri_adjust", v).apply() }

    var lastSurah: Int
        get() = sp.getInt("last_surah", 0)
        set(v) { sp.edit().putInt("last_surah", v).apply() }

    var quranTextSize: Int
        get() = sp.getInt("quran_text_size", 26)
        set(v) { sp.edit().putInt("quran_text_size", v).apply() }

    var firstRunDone: Boolean
        get() = sp.getBoolean("first_run_done", false)
        set(v) { sp.edit().putBoolean("first_run_done", v).apply() }

    var notifAsked: Boolean
        get() = sp.getBoolean("notif_asked", false)
        set(v) { sp.edit().putBoolean("notif_asked", v).apply() }

    // ---- إعدادات كل صلاة على حدة (0 = الفجر ... 4 = العشاء) ----

    fun adhanOn(p: Int): Boolean = sp.getBoolean("adhan_on_$p", true)
    fun setAdhanOn(p: Int, v: Boolean) { sp.edit().putBoolean("adhan_on_$p", v).apply() }

    /** نوع الصوت: chime | system | raw:<name> | file */
    fun soundType(p: Int): String = sp.getString("sound_type_$p", "chime") ?: "chime"
    fun setSoundType(p: Int, v: String) { sp.edit().putString("sound_type_$p", v).apply() }

    /** اسم معروض للصوت المختار. */
    fun soundName(p: Int): String = sp.getString("sound_name_$p", "") ?: ""
    fun setSoundName(p: Int, v: String) { sp.edit().putString("sound_name_$p", v).apply() }

    /** تعديل يدوي بالدقائق (من -15 إلى +15). */
    fun offset(p: Int): Int = sp.getInt("offset_$p", 0)
    fun setOffset(p: Int, v: Int) { sp.edit().putInt("offset_$p", v.coerceIn(-15, 15)).apply() }
}
