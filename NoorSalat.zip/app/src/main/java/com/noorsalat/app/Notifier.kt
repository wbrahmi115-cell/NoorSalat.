package com.noorsalat.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon

object Notifier {
    const val CH_PLAYBACK = "adhan_playback_v1"
    const val CH_REMINDER = "prayer_reminder_v1"
    const val CH_TIME = "prayer_time_v1"

    const val ID_PLAYBACK = 4101
    private const val ID_PRE_BASE = 4200
    private const val ID_TIME_BASE = 4300

    private fun manager(ctx: Context): NotificationManager =
        ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun ensureChannels(ctx: Context) {
        val nm = manager(ctx)

        // الصوت يُشغَّل عبر MediaPlayer، لذلك القناة صامتة حتى لا يتكرر الصوت
        val playback = NotificationChannel(
            CH_PLAYBACK, ctx.getString(R.string.channel_playback), NotificationManager.IMPORTANCE_HIGH
        )
        playback.description = "إشعار يظهر أثناء تشغيل الأذان مع زر الإيقاف"
        playback.setSound(null, null)
        playback.enableVibration(false)

        val reminder = NotificationChannel(
            CH_REMINDER, ctx.getString(R.string.channel_reminder), NotificationManager.IMPORTANCE_DEFAULT
        )
        reminder.description = "تنبيه قبل دخول وقت الصلاة بعدة دقائق"

        val time = NotificationChannel(
            CH_TIME, ctx.getString(R.string.channel_time), NotificationManager.IMPORTANCE_HIGH
        )
        time.description = "إشعار عند دخول وقت الصلاة (للصلوات التي أذانها معطّل)"

        nm.createNotificationChannel(playback)
        nm.createNotificationChannel(reminder)
        nm.createNotificationChannel(time)
    }

    private fun contentIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun showPre(ctx: Context, p: Prayer, minutes: Int, prayerTime: String) {
        ensureChannels(ctx)
        val n = Notification.Builder(ctx, CH_REMINDER)
            .setSmallIcon(R.drawable.ic_stat_noor)
            .setContentTitle("اقترب وقت صلاة " + p.nameAr)
            .setContentText("بقي " + minutes + " دقيقة على صلاة " + p.nameAr + " (" + prayerTime + ")")
            .setContentIntent(contentIntent(ctx))
            .setCategory(Notification.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .build()
        manager(ctx).notify(ID_PRE_BASE + p.ordinal, n)
    }

    fun showTime(ctx: Context, p: Prayer) {
        ensureChannels(ctx)
        val n = Notification.Builder(ctx, CH_TIME)
            .setSmallIcon(R.drawable.ic_stat_noor)
            .setContentTitle("حان الآن وقت صلاة " + p.nameAr)
            .setContentText("حيّ على الصلاة")
            .setContentIntent(contentIntent(ctx))
            .setCategory(Notification.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .build()
        manager(ctx).notify(ID_TIME_BASE + p.ordinal, n)
    }

    fun buildPlayback(ctx: Context, p: Prayer, stopIntent: PendingIntent): Notification {
        ensureChannels(ctx)
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(ctx, R.drawable.ic_stat_noor),
            "إيقاف الأذان",
            stopIntent
        ).build()
        return Notification.Builder(ctx, CH_PLAYBACK)
            .setSmallIcon(R.drawable.ic_stat_noor)
            .setContentTitle("أذان صلاة " + p.nameAr)
            .setContentText("اضغط «إيقاف الأذان» لإسكات الصوت")
            .setContentIntent(contentIntent(ctx))
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .addAction(stopAction)
            .build()
    }
}
