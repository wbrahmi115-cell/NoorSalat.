package com.noorsalat.app

import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/** ألوان التطبيق: أخضر داكن وذهبي. */
object Colors {
    val BG = Color.parseColor("#0B2E22")
    val CARD = Color.parseColor("#124030")
    val CARD_HI = Color.parseColor("#1D5C45")
    val GOLD = Color.parseColor("#D4AF37")
    val GOLD_DIM = Color.parseColor("#8A7424")
    val TEXT = Color.parseColor("#F5F1E3")
    val MUTED = Color.parseColor("#A9C2B6")
    val TRACK_OFF = Color.parseColor("#2C4A3E")
    val WARN = Color.parseColor("#E8A33D")
    val OK = Color.parseColor("#4CC38A")
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun rounded(color: Int, radiusPx: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable {
    val d = GradientDrawable()
    d.shape = GradientDrawable.RECTANGLE
    d.cornerRadius = radiusPx
    d.setColor(color)
    if (strokePx > 0) d.setStroke(strokePx, strokeColor)
    return d
}

fun Context.label(
    text: String,
    sizeSp: Float = 16f,
    color: Int = Colors.TEXT,
    bold: Boolean = false
): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    t.textDirection = View.TEXT_DIRECTION_RTL
    t.gravity = Gravity.START
    return t
}

fun Context.vbox(padDp: Int = 0): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp))
    return l
}

fun Context.hbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.HORIZONTAL
    l.gravity = Gravity.CENTER_VERTICAL
    return l
}

fun Context.card(): LinearLayout {
    val l = vbox(14)
    l.background = rounded(Colors.CARD, dp(16).toFloat())
    return l
}

/** إضافة عنصر إلى LinearLayout مع هامش علوي بالـ dp. */
fun LinearLayout.put(
    v: View,
    topDp: Int = 0,
    w: Int = MATCH,
    h: Int = WRAP,
    weight: Float = 0f
) {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.topMargin = context.dp(topDp)
    addView(v, p)
}

fun Context.goldButton(text: String, filled: Boolean = true, onClick: () -> Unit): TextView {
    val b = label(text, 14f, if (filled) Colors.BG else Colors.GOLD, true)
    b.gravity = Gravity.CENTER
    b.setPadding(dp(14), dp(10), dp(14), dp(10))
    b.background = if (filled) {
        rounded(Colors.GOLD, dp(12).toFloat())
    } else {
        rounded(0, dp(12).toFloat(), Colors.GOLD, dp(1))
    }
    b.setOnClickListener { onClick() }
    return b
}

fun Context.goldSwitch(checked: Boolean, onChange: (Boolean) -> Unit): Switch {
    val s = Switch(this)
    s.isChecked = checked
    val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
    s.thumbTintList = ColorStateList(states, intArrayOf(Colors.GOLD, Colors.MUTED))
    s.trackTintList = ColorStateList(states, intArrayOf(Colors.GOLD_DIM, Colors.TRACK_OFF))
    s.setOnCheckedChangeListener { _, v -> onChange(v) }
    return s
}

fun Context.divider(): View {
    val v = View(this)
    v.setBackgroundColor(Colors.TRACK_OFF)
    return v
}

fun Context.sectionTitle(text: String): TextView {
    val t = label(text, 17f, Colors.GOLD, true)
    t.setPadding(dp(4), dp(18), dp(4), dp(8))
    return t
}

fun Context.dialogBuilder(): AlertDialog.Builder =
    AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
