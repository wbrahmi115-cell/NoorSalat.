package com.noorsalat.app

import android.content.Context
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

enum class Prayer(val nameAr: String) {
    FAJR("الفجر"),
    DHUHR("الظهر"),
    ASR("العصر"),
    MAGHRIB("المغرب"),
    ISHA("العشاء");

    companion object {
        fun fromIndex(i: Int): Prayer = values()[i.coerceIn(0, 4)]
    }
}

/** طريقة حساب: زاوية الفجر والعشاء، أو عدد دقائق بعد المغرب للعشاء إن كانت أكبر من صفر. */
data class Method(
    val id: String,
    val nameAr: String,
    val fajrAngle: Double,
    val ishaAngle: Double,
    val ishaMinutesAfterMaghrib: Int = 0
)

object Methods {
    const val DEFAULT_ID = "tunisia"

    val all: List<Method> = listOf(
        Method("tunisia", "الطريقة التونسية (الفجر 18° / العشاء 18°)", 18.0, 18.0),
        Method("mwl", "رابطة العالم الإسلامي (الفجر 18° / العشاء 17°)", 18.0, 17.0),
        Method("egypt", "الهيئة المصرية العامة للمساحة (19.5° / 17.5°)", 19.5, 17.5),
        Method("ummalqura", "أم القرى (الفجر 18.5° / العشاء 90 دقيقة بعد المغرب)", 18.5, 0.0, 90)
    )

    fun byId(id: String): Method = all.firstOrNull { it.id == id } ?: all[0]
}

class DayTimes(
    val date: LocalDate,
    val fajr: ZonedDateTime,
    val sunrise: ZonedDateTime,
    val dhuhr: ZonedDateTime,
    val asr: ZonedDateTime,
    val maghrib: ZonedDateTime,
    val isha: ZonedDateTime
) {
    fun of(p: Prayer): ZonedDateTime = when (p) {
        Prayer.FAJR -> fajr
        Prayer.DHUHR -> dhuhr
        Prayer.ASR -> asr
        Prayer.MAGHRIB -> maghrib
        Prayer.ISHA -> isha
    }

    fun millis(p: Prayer): Long = of(p).toInstant().toEpochMilli()

    /** تطبيق تعديل يدوي بالدقائق على كل صلاة (الشروق لا يتغير). */
    fun withOffsets(o: IntArray): DayTimes = DayTimes(
        date,
        fajr.plusMinutes(o[0].toLong()),
        sunrise,
        dhuhr.plusMinutes(o[1].toLong()),
        asr.plusMinutes(o[2].toLong()),
        maghrib.plusMinutes(o[3].toLong()),
        isha.plusMinutes(o[4].toLong())
    )
}

/**
 * حساب فلكي محلي بالكامل (دون إنترنت ودون أي خدمة خارجية).
 * الخوارزمية: موضع الشمس التقريبي (ميل الشمس ومعادلة الزمن) ثم حل زاوية الساعة
 * لكل صلاة. الدقة المتوقعة: ± دقيقة إلى دقيقتين مقارنة بالجداول الرسمية.
 */
object PrayerCalculator {
    private const val RISE_SET_ANGLE = 0.833 // انكسار الضوء + نصف قطر الشمس

    private fun dtr(d: Double) = d * PI / 180.0
    private fun rtd(r: Double) = r * 180.0 / PI
    private fun sinD(d: Double) = sin(dtr(d))
    private fun cosD(d: Double) = cos(dtr(d))
    private fun tanD(d: Double) = tan(dtr(d))
    private fun asinD(x: Double) = rtd(asin(x))
    private fun acosD(x: Double) = rtd(acos(x))
    private fun acotD(x: Double) = rtd(atan(1.0 / x))

    private fun fixAngle(a: Double): Double {
        val r = a % 360.0
        return if (r < 0) r + 360.0 else r
    }

    private fun fixHour(h: Double): Double {
        val r = h % 24.0
        return if (r < 0) r + 24.0 else r
    }

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    /** يعيد [ميل الشمس بالدرجات، معادلة الزمن بالساعات]. */
    private fun sunPosition(jd: Double): DoubleArray {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sinD(g) + 0.020 * sinD(2 * g))
        val e = 23.439 - 0.00000036 * d
        val ra = fixHour(rtd(atan2(cosD(e) * sinD(l), cosD(l))) / 15.0)
        // تطبيع الفرق إلى [-12, 12) لتفادي قفزة 24 ساعة عند حدود الدورة
        var eqt = q / 15.0 - ra
        eqt = ((eqt + 12.0) % 24.0 + 24.0) % 24.0 - 12.0
        val decl = asinD(sinD(e) * sinD(l))
        return doubleArrayOf(decl, eqt)
    }

    private fun midDay(jd: Double, t: Double): Double = fixHour(12.0 - sunPosition(jd + t)[1])

    /** وقت (بالساعات) تكون فيه الشمس تحت الأفق بزاوية [angle] درجة. */
    private fun sunAngleTime(jd: Double, lat: Double, angle: Double, t: Double, ccw: Boolean): Double {
        val decl = sunPosition(jd + t)[0]
        val noon = midDay(jd, t)
        val x = (-sinD(angle) - sinD(decl) * sinD(lat)) / (cosD(decl) * cosD(lat))
        val hours = acosD(x.coerceIn(-1.0, 1.0)) / 15.0
        return if (ccw) noon - hours else noon + hours
    }

    private fun asrTime(jd: Double, lat: Double, factor: Double, t: Double): Double {
        val decl = sunPosition(jd + t)[0]
        val angle = -acotD(factor + tanD(abs(lat - decl)))
        return sunAngleTime(jd, lat, angle, t, false)
    }

    private fun toZoned(date: LocalDate, hours: Double, zone: ZoneId): ZonedDateTime {
        val minutes = Math.round(hours * 60.0)
        return date.atStartOfDay(zone).plusMinutes(minutes)
    }

    fun compute(date: LocalDate, city: City, method: Method, hanafi: Boolean): DayTimes {
        val zone = Cities.ZONE
        val tz = date.atTime(12, 0).atZone(zone).offset.totalSeconds / 3600.0
        val lat = city.lat
        val lng = city.lng
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - lng / (15.0 * 24.0)
        val asrFactor = if (hanafi) 2.0 else 1.0

        var fajr = 5.0
        var sunrise = 6.0
        var dhuhr = 12.0
        var asr = 13.0
        var sunset = 18.0
        var isha = 18.0
        for (i in 0 until 2) {
            fajr = sunAngleTime(jd, lat, method.fajrAngle, fajr / 24.0, true)
            sunrise = sunAngleTime(jd, lat, RISE_SET_ANGLE, sunrise / 24.0, true)
            dhuhr = midDay(jd, dhuhr / 24.0)
            asr = asrTime(jd, lat, asrFactor, asr / 24.0)
            sunset = sunAngleTime(jd, lat, RISE_SET_ANGLE, sunset / 24.0, false)
            isha = sunAngleTime(jd, lat, method.ishaAngle, isha / 24.0, false)
        }

        val adjust = tz - lng / 15.0
        val maghribH = sunset + adjust
        val ishaH = if (method.ishaMinutesAfterMaghrib > 0) {
            maghribH + method.ishaMinutesAfterMaghrib / 60.0
        } else {
            isha + adjust
        }

        return DayTimes(
            date = date,
            fajr = toZoned(date, fajr + adjust, zone),
            sunrise = toZoned(date, sunrise + adjust, zone),
            dhuhr = toZoned(date, dhuhr + adjust, zone),
            asr = toZoned(date, asr + adjust, zone),
            maghrib = toZoned(date, maghribH, zone),
            isha = toZoned(date, ishaH, zone)
        )
    }
}

/** يقرأ إعدادات المستخدم (المدينة والطريقة والتعديلات) ويعيد مواقيت اليوم المطلوب. */
object TimesProvider {
    fun get(ctx: Context, date: LocalDate): DayTimes {
        val prefs = Prefs(ctx)
        val base = PrayerCalculator.compute(
            date,
            Cities.byId(prefs.cityId),
            Methods.byId(prefs.methodId),
            prefs.hanafi
        )
        return base.withOffsets(IntArray(5) { prefs.offset(it) })
    }
}
