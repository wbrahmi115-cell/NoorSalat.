package com.noorsalat.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale

class MainActivity : Activity() {

    interface Screen {
        val root: View
        fun onShow() {}
        fun onHide() {}
        fun onBack(): Boolean = false
    }

    lateinit var prefs: Prefs
    private lateinit var content: FrameLayout
    private val screens = ArrayList<Screen>()
    private val tabButtons = ArrayList<TextView>()
    private var current = -1
    private lateinit var homeScreen: HomeScreen
    private lateinit var settingsScreen: SettingsScreen
    private var askBatteryAfterNotif = false

    override fun attachBaseContext(base: Context) {
        // فرض اللغة العربية واتجاه RTL على كل نوافذ التطبيق
        val loc = Locale("ar")
        Locale.setDefault(loc)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(loc)
        cfg.setLayoutDirection(loc)
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        Notifier.ensureChannels(this)
        Scheduler.rescheduleAll(this)
        RescheduleJobService.ensureScheduled(this)

        homeScreen = HomeScreen(this)
        settingsScreen = SettingsScreen(this)
        screens.add(homeScreen)
        screens.add(QiblaScreen(this))
        screens.add(QuranScreen(this))
        screens.add(AzkarScreen(this))
        screens.add(settingsScreen)

        val root = vbox()
        root.setBackgroundColor(Colors.BG)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL

        content = FrameLayout(this)
        root.put(content, 0, MATCH, 0, 1f)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.background = rounded(Colors.CARD, 0f)
        bar.setPadding(0, dp(6), 0, dp(6))
        val names = arrayOf("🕌\nالرئيسية", "🧭\nالقبلة", "📖\nالقرآن", "📿\nالأذكار", "⚙️\nالإعدادات")
        for (i in names.indices) {
            val b = TextView(this)
            b.text = names[i]
            b.textSize = 11f
            b.gravity = Gravity.CENTER
            b.setPadding(0, dp(4), 0, dp(4))
            b.setOnClickListener { select(i) }
            bar.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
            tabButtons.add(b)
        }
        root.put(bar, 0, MATCH, WRAP)

        setContentView(root)

        if (!prefs.firstRunDone) showWelcome()
    }

    override fun onResume() {
        super.onResume()
        if (current < 0) select(0) else screens[current].onShow()
    }

    override fun onPause() {
        if (current >= 0) screens[current].onHide()
        super.onPause()
    }

    private fun select(i: Int) {
        if (current >= 0) screens[current].onHide()
        content.removeAllViews()
        content.addView(screens[i].root, FrameLayout.LayoutParams(MATCH, MATCH))
        current = i
        for (k in tabButtons.indices) {
            val sel = k == i
            tabButtons[k].setTextColor(if (sel) Colors.GOLD else Colors.MUTED)
            tabButtons[k].setTypeface(null, if (sel) Typeface.BOLD else Typeface.NORMAL)
        }
        screens[i].onShow()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (current >= 0 && screens[current].onBack()) return
        if (current > 0) select(0) else super.onBackPressed()
    }

    // ---------- حوارات مشتركة ----------

    fun pickCity(onDone: () -> Unit) {
        val names = Cities.all.map { it.nameAr }.toTypedArray()
        val checked = Cities.all.indexOfFirst { it.id == prefs.cityId }
        dialogBuilder()
            .setTitle("اختر المدينة")
            .setSingleChoiceItems(names, checked) { d, which ->
                prefs.cityId = Cities.all[which].id
                Scheduler.rescheduleAll(this)
                d.dismiss()
                onDone()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun showWelcome() {
        dialogBuilder()
            .setTitle("مرحبًا بك في «نور الصلاة»")
            .setMessage(
                "لكي يعمل الأذان في وقته والشاشة مغلقة نحتاج إلى:\n\n" +
                    "• إذن الإشعارات.\n" +
                    "• استثناء التطبيق من توفير البطارية (مهم جدًا في هواتف OPPO).\n\n" +
                    "يمكنك تغيير ذلك لاحقًا من تبويب الإعدادات. التطبيق لا يستخدم الإنترنت ولا يجمع أي بيانات."
            )
            .setCancelable(false)
            .setPositiveButton("متابعة") { _, _ ->
                prefs.firstRunDone = true
                askBatteryAfterNotif = true
                Perms.requestNotifications(this, prefs)
            }
            .setNegativeButton("لاحقًا") { _, _ -> prefs.firstRunDone = true }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == Perms.REQ_NOTIFICATIONS) {
            if (!Perms.notificationsEnabled(this)) {
                Toast.makeText(this, "الإشعارات غير مفعّلة، لن تظهر تنبيهات الصلاة.", Toast.LENGTH_LONG).show()
            }
            if (askBatteryAfterNotif && !Perms.batteryExempt(this)) {
                askBatteryAfterNotif = false
                Perms.requestBatteryExemption(this)
            }
            homeScreen.refresh()
            settingsScreen.refresh()
        }
    }

    // ---------- اختيار ملف أذان من الهاتف ----------

    fun pickAudioFor(prayerIdx: Int) {
        try {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "audio/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(Intent.createChooser(i, "اختر ملف الأذان"), REQ_AUDIO_BASE + prayerIdx)
        } catch (e: Exception) {
            Toast.makeText(this, "تعذّر فتح مُنتقي الملفات", Toast.LENGTH_LONG).show()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val idx = requestCode - REQ_AUDIO_BASE
        if (idx < 0 || idx > 4 || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        val app = applicationContext
        Thread {
            var ok = false
            var name = "ملف مخصص"
            try {
                val c = app.contentResolver.query(uri, null, null, null, null)
                if (c != null) {
                    try {
                        val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (col >= 0 && c.moveToFirst()) name = c.getString(col) ?: name
                    } finally {
                        c.close()
                    }
                }
                val dest = File(app.filesDir, "adhan_" + idx)
                val input = app.contentResolver.openInputStream(uri)
                if (input != null) {
                    input.use { ins -> dest.outputStream().use { out -> ins.copyTo(out) } }
                    ok = dest.length() > 0
                }
            } catch (e: Exception) {
                ok = false
            }
            runOnUiThread {
                if (ok) {
                    prefs.setSoundType(idx, "file")
                    prefs.setSoundName(idx, name)
                    Toast.makeText(this, "تم حفظ الملف لصلاة " + Prayer.fromIndex(idx).nameAr, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "تعذّر نسخ الملف الصوتي", Toast.LENGTH_LONG).show()
                }
                settingsScreen.refresh()
            }
        }.start()
    }

    companion object {
        private const val REQ_AUDIO_BASE = 2000
    }
}
