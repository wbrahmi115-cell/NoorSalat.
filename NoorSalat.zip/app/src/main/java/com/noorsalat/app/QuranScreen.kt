package com.noorsalat.app

import android.graphics.Color
import android.text.Editable
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class QuranScreen(private val act: MainActivity) : MainActivity.Screen {

    private val host = FrameLayout(act)
    override val root: View get() = host

    private val rows = ArrayList<Pair<View, String>>()
    private val listView: View
    private var readerOpen = false
    private var readerText: TextView? = null

    init {
        listView = buildList()
        host.addView(listView, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    override fun onBack(): Boolean {
        if (readerOpen) {
            showList()
            return true
        }
        return false
    }

    private fun showList() {
        readerOpen = false
        readerText = null
        host.removeAllViews()
        host.addView(listView, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun normalize(s: String): String =
        s.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ة', 'ه').replace('ى', 'ي')

    private fun buildList(): View {
        val scroll = ScrollView(act)
        val body = act.vbox(16)
        scroll.addView(body)

        body.put(act.label("القرآن الكريم", 26f, Colors.GOLD, true))

        val full = QuranRepo.hasFullText(act)
        val note = if (full) {
            "المصحف كاملًا (114 سورة) يعمل دون إنترنت."
        } else {
            "ملاحظة: هذه النسخة تحتوي على سور قصيرة فقط (الفاتحة، العصر، الكوثر، النصر، الإخلاص، الفلق، الناس). " +
                "النص الكامل يُضاف تلقائيًا عند البناء عبر GitHub Actions (انظر ملف README)."
        }
        body.put(act.label(note, 12f, if (full) Colors.MUTED else Colors.WARN), 6)

        val last = act.prefs.lastSurah
        if (last in 1..114) {
            body.put(act.goldButton("متابعة القراءة: سورة " + QuranRepo.NAMES[last - 1], true) { openSurah(last) }, 12)
        }

        val search = EditText(act)
        search.hint = "ابحث باسم السورة أو رقمها"
        search.setHintTextColor(Colors.MUTED)
        search.setTextColor(Colors.TEXT)
        search.setSingleLine(true)
        search.textDirection = View.TEXT_DIRECTION_RTL
        search.setPadding(act.dp(14), act.dp(10), act.dp(14), act.dp(10))
        search.background = rounded(Colors.CARD, act.dp(12).toFloat())
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = normalize(s?.toString()?.trim() ?: "")
                for (r in rows) {
                    r.first.visibility = if (q.isEmpty() || r.second.contains(q)) View.VISIBLE else View.GONE
                }
            }
        })
        body.put(search, 12)

        for (i in 0 until 114) {
            val n = i + 1
            val row = act.hbox()
            row.setPadding(act.dp(12), act.dp(12), act.dp(12), act.dp(12))
            row.background = rounded(Colors.CARD, act.dp(12).toFloat())
            val badge = act.label(n.toString(), 13f, Colors.BG, true)
            badge.gravity = Gravity.CENTER
            badge.background = rounded(Colors.GOLD, act.dp(14).toFloat())
            val bp = LinearLayout.LayoutParams(act.dp(34), act.dp(28))
            bp.marginEnd = act.dp(12)
            row.addView(badge, bp)
            row.put(act.label(QuranRepo.NAMES[i], 18f, Colors.TEXT, true), 0, 0, WRAP, 1f)
            row.put(act.label(QuranRepo.COUNTS[i].toString() + " آية", 12f, Colors.MUTED), 0, WRAP, WRAP)
            row.setOnClickListener { openSurah(n) }
            body.put(row, 8)
            rows.add(Pair(row, normalize(n.toString() + " " + QuranRepo.NAMES[i])))
        }
        return scroll
    }

    private fun openSurah(n: Int) {
        if (n < 1 || n > 114) return
        act.prefs.lastSurah = n
        readerOpen = true

        val scroll = ScrollView(act)
        val body = act.vbox(16)
        scroll.addView(body)

        // شريط علوي: رجوع + حجم الخط
        val top = act.hbox()
        top.put(act.goldButton("→ الفهرس", false) { showList() }, 0, WRAP, WRAP)
        top.put(act.label("", 1f), 0, 0, WRAP, 1f)
        top.put(act.goldButton("A−", false) { changeSize(-2) }, 0, WRAP, WRAP)
        val plus = act.goldButton("A+", false) { changeSize(2) }
        val pp = LinearLayout.LayoutParams(WRAP, WRAP)
        pp.marginStart = act.dp(8)
        top.addView(plus, pp)
        body.put(top)

        val title = act.label("سورة " + QuranRepo.NAMES[n - 1], 28f, Colors.GOLD, true)
        title.gravity = Gravity.CENTER
        body.put(title, 14)
        val sub = act.label(QuranRepo.COUNTS[n - 1].toString() + " آية", 13f, Colors.MUTED)
        sub.gravity = Gravity.CENTER
        body.put(sub, 2)

        val ayahs = QuranRepo.ayahs(act, n)
        if (ayahs == null) {
            val c = act.card()
            c.put(act.label("نص هذه السورة غير متوفر في هذه النسخة من التطبيق.", 16f, Colors.WARN, true))
            c.put(
                act.label(
                    "يُضاف المصحف الكامل تلقائيًا عند بناء التطبيق عبر GitHub Actions. " +
                        "إن بنيت التطبيق ولم يظهر النص فراجع ملف README لمعرفة السبب.",
                    14f, Colors.TEXT
                ),
                8
            )
            body.put(c, 20)
        } else {
            if (n != 1 && n != 9) {
                val bis = act.label("بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ", 24f, Colors.GOLD, true)
                bis.gravity = Gravity.CENTER
                body.put(bis, 18)
            }
            val tv = TextView(act)
            tv.setTextColor(Colors.TEXT)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, act.prefs.quranTextSize.toFloat())
            tv.setLineSpacing(0f, 1.7f)
            tv.textDirection = View.TEXT_DIRECTION_RTL
            tv.gravity = Gravity.START
            tv.justificationMode = Layout.JUSTIFICATION_MODE_INTER_WORD
            tv.setTextIsSelectable(true)

            val sb = SpannableStringBuilder()
            for (i in ayahs.indices) {
                sb.append(ayahs[i])
                val start = sb.length
                sb.append(" ﴿" + Util.arabicIndic(i + 1) + "﴾ ")
                sb.setSpan(ForegroundColorSpan(Colors.GOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            tv.text = sb
            readerText = tv
            body.put(tv, 16)
        }

        // التنقل بين السور
        val nav = act.hbox()
        if (n > 1) nav.put(act.goldButton("← " + QuranRepo.NAMES[n - 2], false) { openSurah(n - 1) }, 0, WRAP, WRAP)
        nav.put(act.label("", 1f), 0, 0, WRAP, 1f)
        if (n < 114) nav.put(act.goldButton(QuranRepo.NAMES[n] + " →", false) { openSurah(n + 1) }, 0, WRAP, WRAP)
        body.put(nav, 24)

        host.removeAllViews()
        host.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        scroll.post { scroll.scrollTo(0, 0) }
    }

    private fun changeSize(delta: Int) {
        val s = (act.prefs.quranTextSize + delta).coerceIn(18, 44)
        act.prefs.quranTextSize = s
        readerText?.setTextSize(TypedValue.COMPLEX_UNIT_SP, s.toFloat())
    }
}
