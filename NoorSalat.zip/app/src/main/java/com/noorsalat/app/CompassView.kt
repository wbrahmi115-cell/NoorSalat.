package com.noorsalat.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.View
import kotlin.math.abs
import kotlin.math.min

/** بوصلة القبلة: قرص يدور حسب اتجاه الهاتف، وعلامة ذهبية عند اتجاه القبلة. */
class CompassView(context: Context) : View(context) {

    private var heading = 0f
    private var qibla = 0f
    private var hasHeading = false

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init {
        ring.style = Paint.Style.STROKE
        ring.strokeWidth = context.dp(3).toFloat()
        tick.style = Paint.Style.STROKE
        tick.strokeCap = Paint.Cap.ROUND
        txt.textAlign = Paint.Align.CENTER
        txt.typeface = Typeface.DEFAULT_BOLD
        txt.textSize = context.dp(18).toFloat()
        fill.style = Paint.Style.FILL
    }

    fun setQibla(deg: Float) {
        qibla = deg
        invalidate()
    }

    fun setHeading(deg: Float) {
        heading = deg
        hasHeading = true
        invalidate()
    }

    fun isAligned(): Boolean {
        if (!hasHeading) return false
        val d = ((qibla - heading + 540f) % 360f) - 180f
        return abs(d) < ALIGN_TOLERANCE
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, w)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy) - context.dp(12)
        val aligned = isAligned()

        // قاعدة القرص
        fill.color = Colors.CARD
        canvas.drawCircle(cx, cy, r, fill)
        ring.color = if (aligned) Colors.OK else Colors.GOLD
        canvas.drawCircle(cx, cy, r, ring)

        // القرص الدوّار (الشمال في الأعلى عندما يكون الاتجاه 0)
        canvas.save()
        canvas.rotate(-heading, cx, cy)

        for (a in 0 until 360 step 10) {
            val major = a % 90 == 0
            val mid = a % 30 == 0
            tick.color = if (major) Colors.GOLD else Colors.MUTED
            tick.strokeWidth = context.dp(if (major) 3 else if (mid) 2 else 1).toFloat()
            val len = context.dp(if (major) 16 else if (mid) 11 else 6).toFloat()
            canvas.save()
            canvas.rotate(a.toFloat(), cx, cy)
            canvas.drawLine(cx, cy - r + context.dp(6), cx, cy - r + context.dp(6) + len, tick)
            canvas.restore()
        }

        // حروف الجهات: ش شمال، شر شرق، ج جنوب، غ غرب
        val letters = arrayOf("ش", "شر", "ج", "غ")
        txt.color = Colors.TEXT
        for (k in 0 until 4) {
            canvas.save()
            canvas.rotate(k * 90f, cx, cy)
            canvas.drawText(letters[k], cx, cy - r + context.dp(46), txt)
            canvas.restore()
        }

        // علامة القبلة على القرص
        canvas.save()
        canvas.rotate(qibla, cx, cy)
        tick.color = Colors.GOLD
        tick.strokeWidth = context.dp(2).toFloat()
        canvas.drawLine(cx, cy, cx, cy - r + context.dp(70), tick)
        fill.color = Colors.GOLD
        canvas.drawCircle(cx, cy - r + context.dp(70), context.dp(14).toFloat(), fill)
        fill.color = Colors.BG
        val s = context.dp(7).toFloat()
        canvas.drawRect(cx - s, cy - r + context.dp(70) - s, cx + s, cy - r + context.dp(70) + s, fill)
        canvas.restore()

        canvas.restore()

        // مؤشر ثابت في الأعلى يمثّل اتجاه الهاتف
        path.reset()
        path.moveTo(cx, cy - r - context.dp(2))
        path.lineTo(cx - context.dp(10), cy - r + context.dp(20))
        path.lineTo(cx + context.dp(10), cy - r + context.dp(20))
        path.close()
        fill.color = if (aligned) Colors.OK else Colors.TEXT
        canvas.drawPath(path, fill)

        // مركز القرص
        fill.color = if (aligned) Colors.OK else Colors.GOLD
        canvas.drawCircle(cx, cy, context.dp(6).toFloat(), fill)
    }

    companion object {
        private const val ALIGN_TOLERANCE = 4f
    }
}
