package com.noorsalat.app

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import java.io.File
import java.io.IOException

/**
 * خدمة أمامية (foreground service من نوع mediaPlayback) تشغّل صوت الأذان
 * حتى لو كانت الشاشة مغلقة والتطبيق في الخلفية.
 */
class AdhanService : Service() {

    private var player: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var focusRequest: AudioFocusRequest? = null
    private val handler = Handler(Looper.getMainLooper())
    private val timeoutStop = Runnable { stopAll() }
    private val focusListener = AudioManager.OnAudioFocusChangeListener { }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAll()
            return START_NOT_STICKY
        }

        val idx = intent?.getIntExtra(Scheduler.EXTRA_PRAYER, 0) ?: 0
        val prayer = Prayer.fromIndex(idx)

        // يجب استدعاء startForeground فورًا بعد البدء
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, AdhanService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notifier.buildPlayback(this, prayer, stopPi)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(Notifier.ID_PLAYBACK, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(Notifier.ID_PLAYBACK, notification)
        }

        acquireWakeLock()
        startPlayback(idx)
        return START_NOT_STICKY
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock?.isHeld == true) return
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NoorSalat:adhan")
            wl.acquire(MAX_PLAY_MS + 30_000L)
            wakeLock = wl
        } catch (e: Exception) {
            // غير حرج
        }
    }

    private fun startPlayback(prayerIdx: Int) {
        stopPlayer()
        handler.removeCallbacks(timeoutStop)

        val prefs = Prefs(this)
        val usage = if (prefs.audioStream == "media") AudioAttributes.USAGE_MEDIA else AudioAttributes.USAGE_ALARM
        val attrs = AudioAttributes.Builder()
            .setUsage(usage)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        requestFocus(attrs)

        val type = prefs.soundType(prayerIdx)
        var mp = tryPlay(attrs, type, prayerIdx)
        if (mp == null && type != "chime") {
            mp = tryPlay(attrs, "chime", prayerIdx) // الصوت المختار تعذّر: نعود للنغمة المدمجة
        }
        if (mp == null) {
            stopAll()
            return
        }
        player = mp
        handler.postDelayed(timeoutStop, MAX_PLAY_MS)
    }

    private fun tryPlay(attrs: AudioAttributes, type: String, prayerIdx: Int): MediaPlayer? {
        val mp = MediaPlayer()
        return try {
            mp.setAudioAttributes(attrs)
            mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            setSource(mp, type, prayerIdx)
            mp.setOnCompletionListener { handler.post { stopAll() } }
            mp.setOnErrorListener { _, _, _ ->
                handler.post { stopAll() }
                true
            }
            mp.prepare()
            mp.start()
            mp
        } catch (e: Exception) {
            try {
                mp.release()
            } catch (ignored: Exception) {
            }
            null
        }
    }

    private fun setSource(mp: MediaPlayer, type: String, prayerIdx: Int) {
        if (type == "system") {
            var uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            mp.setDataSource(this, uri)
        } else if (type == "file") {
            val f = File(filesDir, "adhan_" + prayerIdx)
            if (!f.exists()) throw IOException("الملف الصوتي غير موجود")
            mp.setDataSource(f.absolutePath)
        } else if (type.startsWith("raw:")) {
            val id = resources.getIdentifier(type.removePrefix("raw:"), "raw", packageName)
            if (id == 0) throw IOException("المورد الصوتي غير موجود")
            setRaw(mp, id)
        } else {
            setRaw(mp, R.raw.chime_soft)
        }
    }

    private fun setRaw(mp: MediaPlayer, resId: Int) {
        val afd = resources.openRawResourceFd(resId)
        try {
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
        } finally {
            afd.close()
        }
    }

    private fun requestFocus(attrs: AudioAttributes) {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(focusListener)
                .build()
            am.requestAudioFocus(req)
            focusRequest = req
        } catch (e: Exception) {
            // غير حرج
        }
    }

    private fun stopPlayer() {
        val mp = player
        player = null
        if (mp != null) {
            try {
                if (mp.isPlaying) mp.stop()
            } catch (ignored: Exception) {
            }
            try {
                mp.release()
            } catch (ignored: Exception) {
            }
        }
    }

    private fun stopAll() {
        handler.removeCallbacks(timeoutStop)
        stopPlayer()
        try {
            val req = focusRequest
            if (req != null) {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.abandonAudioFocusRequest(req)
            }
        } catch (ignored: Exception) {
        }
        focusRequest = null
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (ignored: Exception) {
        }
        wakeLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(timeoutStop)
        stopPlayer()
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (ignored: Exception) {
        }
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.noorsalat.app.action.STOP_ADHAN"
        private const val MAX_PLAY_MS = 6 * 60_000L

        /** تشغيل صوت صلاة معيّنة فورًا (للمعاينة من الإعدادات والتطبيق في الواجهة). */
        fun preview(ctx: Context, prayerIdx: Int) {
            val i = Intent(ctx, AdhanService::class.java)
            i.putExtra(Scheduler.EXTRA_PRAYER, prayerIdx)
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            val i = Intent(ctx, AdhanService::class.java)
            i.action = ACTION_STOP
            ctx.startService(i)
        }
    }
}
