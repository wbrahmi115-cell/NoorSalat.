package com.noorsalat.app

import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class AzkarScreen(private val act: MainActivity) : MainActivity.Screen {

    private val scroll = ScrollView(act)
    private val body = act.vbox(16)
    override val root: View get() = scroll

    private val sets = listOf(
        Pair("أذكار الصباح", AzkarData.morning),
        Pair("أذكار المساء", AzkarData.evening),
        Pair("بعد الصلاة", AzkarData.afterPrayer)
    )
    private val remaining = ArrayList<IntArray>()
    private var tab = 0
    private val tabButtons = ArrayList<TextView>()
    private val listBox = act.vbox()

    init {
        for (s in sets) remaining.add(IntArray(s.second.size) { s.second[it].count })
        scroll.addView(body)
        body.put(act.label("الأذكار", 26f, Colors.GOLD, true))

        val bar = act.hbox()
        for (i in sets.indices) {
            val b = act.label(sets[i].first, 14f, Colors.TEXT, true)
            b.gravity = Gravity.CENTER
            b.setPadding(act.dp(6), act.dp(10), act.dp(6), act.dp(10))
            b.setOnClickListener {
                tab = i
                render()
            }
            val p = LinearLayout.LayoutParams(0, WRAP, 1f)
            if (i > 0) p.marginStart = act.dp(8)
            bar.addView(b, p)
            tabButtons.add(b)
        }
        body.put(bar, 12)
        body.put(listBox, 8)
        render()
    }

    override fun onShow() {
        // نترك العدّادات كما هي أثناء الجلسة؛ زر «إعادة» يصفّرها
    }

    private fun render() {
        for (i in tabButtons.indices) {
            val sel = i == tab
            tabButtons[i].setTextColor(if (sel) Colors.BG else Colors.TEXT)
            tabButtons[i].background = if (sel) {
                rounded(Colors.GOLD, act.dp(12).toFloat())
            } else {
                rounded(Colors.CARD, act.dp(12).toFloat())
            }
        }

        listBox.removeAllViews()
        val items = sets[tab].second
        val rem = remaining[tab]

        val top = act.hbox()
        top.put(act.label("اضغط على الذِّكر لإنقاص العدّاد.", 12f, Colors.MUTED), 0, 0, WRAP, 1f)
        top.put(act.goldButton("إعادة", false) {
            for (i in items.indices) rem[i] = items[i].count
            render()
        }, 0, WRAP, WRAP)
        listBox.put(top)

        for (i in items.indices) {
            val z = items[i]
            val done = rem[i] == 0
            val c = act.card()
            c.alpha = if (done) 0.45f else 1f

            if (z.hint.isNotEmpty()) c.put(act.label(z.hint, 13f, Colors.GOLD, true))
            val txt = act.label(z.text, 19f, Colors.TEXT)
            txt.setLineSpacing(0f, 1.5f)
            c.put(txt, if (z.hint.isNotEmpty()) 6 else 0)

            val foot = act.hbox()
            foot.put(
                act.label(if (z.count > 1) "التكرار: " + z.count + " مرة" else "مرة واحدة", 12f, Colors.MUTED),
                0, 0, WRAP, 1f
            )
            val counter = act.label(if (done) "✓ تم" else rem[i].toString(), 20f, if (done) Colors.OK else Colors.GOLD, true)
            counter.gravity = Gravity.CENTER
            counter.setPadding(act.dp(18), act.dp(6), act.dp(18), act.dp(6))
            counter.background = rounded(Colors.BG, act.dp(12).toFloat(), Colors.GOLD, act.dp(1))
            foot.put(counter, 0, WRAP, WRAP)
            c.put(foot, 10)

            c.setOnClickListener {
                if (rem[i] > 0) {
                    rem[i] = rem[i] - 1
                    render()
                }
            }
            listBox.put(c, 10)
        }
    }
}
