package com.noorsalat.app

import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

class SettingsScreen(private val act: MainActivity) : MainActivity.Screen {

    private val scroll = ScrollView(act)
    private val body = act.vbox(16)
    override val root: View get() = scroll

    private val prefs: Prefs get() = act.prefs

    init {
        scroll.addView(body)
        build()
    }

    override fun onShow() {
        refresh()
    }

    fun refresh() {
        body.removeAllViews()
        build()
    }

    private fun reschedule() {
        Scheduler.rescheduleAll(act)
    }

    /** صف: عنوان على جهة وعنصر تحكم على الجهة الأخرى. */
    private fun settingRow(title: String, control: View): LinearLayout {
        val r = act.hbox()
        r.setPadding(0, act.dp(8), 0, act.dp(8))
        r.put(act.label(title, 15f, Colors.TEXT), 0, 0, WRAP, 1f)
        val p = LinearLayout.LayoutParams(WRAP, WRAP)
        p.marginStart = act.dp(10)
        r.addView(control, p)
        return r
    }

    private fun build() {
        body.put(act.label("الإعدادات", 26f, Colors.GOLD, true))

        // ================= الموقع وطريقة الحساب =================
        body.addView(act.sectionTitle("المدينة وطريقة الحساب"))
        val c1 = act.card()
        val city = Cities.byId(prefs.cityId)
        c1.put(settingRow("المدينة", act.goldButton(city.nameAr, false) { act.pickCity { refresh() } }))
        c1.put(act.divider(), 0, MATCH, 1)

        val method = Methods.byId(prefs.methodId)
        c1.put(act.label("طريقة الحساب", 15f, Colors.TEXT), 8)
        c1.put(act.goldButton(method.nameAr, false) { pickMethod() }, 6)
        c1.put(
            act.label(
                "الطريقة التونسية: الفجر والعشاء بزاوية 18°. الحساب فلكي محلي ودقته ± دقيقة إلى دقيقتين مقارنة بالجداول الرسمية، " +
                    "ويمكنك تعديل كل صلاة بالدقائق أدناه لتطابق جدول وزارة الشؤون الدينية أو مسجدك.",
                12f, Colors.MUTED
            ),
            8
        )
        c1.put(act.divider(), 8, MATCH, 1)
        c1.put(settingRow("العصر بالمذهب الحنفي (الظل = مثلان)", act.goldSwitch(prefs.hanafi) { v ->
            prefs.hanafi = v
            reschedule()
        }))
        c1.put(act.divider(), 0, MATCH, 1)
        c1.put(settingRow("تعديل التاريخ الهجري", stepper(prefs.hijriAdjust, "يوم") { delta ->
            prefs.hijriAdjust = (prefs.hijriAdjust + delta).coerceIn(-2, 2)
            refresh()
        }))
        body.put(c1)

        // ================= التنبيهات =================
        body.addView(act.sectionTitle("التنبيهات والصوت"))
        val c2 = act.card()
        val pre = prefs.preMinutes
        c2.put(settingRow("تنبيه قبل الصلاة", act.goldButton(if (pre == 0) "معطّل" else "$pre دقيقة", false) { pickPre() }))
        c2.put(act.divider(), 0, MATCH, 1)
        c2.put(settingRow("إشعار عند دخول الوقت (حتى لو الأذان معطّل)", act.goldSwitch(prefs.notifyAtTime) { v ->
            prefs.notifyAtTime = v
            reschedule()
        }))
        c2.put(act.divider(), 0, MATCH, 1)
        c2.put(settingRow("وضع المنبه الدقيق (الأضمن)", act.goldSwitch(prefs.useAlarmClock) { v ->
            prefs.useAlarmClock = v
            reschedule()
        }))
        c2.put(
            act.label(
                "يستخدم نظام المنبهات في أندرويد، فيعمل في الوقت المضبوط حتى في وضع توفير الطاقة العميق، لكنه يُظهر أيقونة منبه صغيرة في شريط الحالة. " +
                    "إيقافه يعتمد على إذن «المنبهات الدقيقة» وقد يتأخر الأذان بضع دقائق على بعض الهواتف.",
                12f, Colors.MUTED
            ),
            4
        )
        c2.put(act.divider(), 8, MATCH, 1)
        val media = prefs.audioStream == "media"
        c2.put(settingRow("قناة صوت الأذان", act.goldButton(if (media) "صوت الوسائط" else "صوت المنبه", false) {
            prefs.audioStream = if (prefs.audioStream == "media") "alarm" else "media"
            refresh()
        }))
        c2.put(
            act.label(
                "«صوت المنبه» يُسمع حتى لو كان الرنين صامتًا (ما لم يكن صوت المنبه مخفوضًا). «صوت الوسائط» يتبع مستوى الوسائط.",
                12f, Colors.MUTED
            ),
            4
        )
        body.put(c2)

        // ================= كل صلاة =================
        body.addView(act.sectionTitle("إعداد كل صلاة على حدة"))
        for (p in Prayer.values()) {
            body.put(prayerCard(p), 10)
        }
        body.put(
            act.label(
                "ملاحظة: التطبيق لا يتضمن تسجيلًا لأذان (لأسباب الحقوق). اختر «ملف صوتي من هاتفك» وحدّد أذانًا تملكه أو مسموحًا لك باستخدامه، " +
                    "أو ضع ملفات باسم adhan_xxx.mp3 داخل app/src/main/res/raw قبل البناء لتظهر في قائمة الأصوات.",
                12f, Colors.MUTED
            ),
            10
        )

        // ================= الأذونات =================
        body.addView(act.sectionTitle("الأذونات والبطارية"))
        val c3 = act.card()

        val notifOk = Perms.notificationsEnabled(act)
        c3.put(permRow("الإشعارات", notifOk, "تفعيل") { Perms.requestNotifications(act, prefs) })
        c3.put(act.divider(), 0, MATCH, 1)

        val batOk = Perms.batteryExempt(act)
        c3.put(permRow("استثناء توفير البطارية", batOk, "استثناء") { Perms.requestBatteryExemption(act) })

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            c3.put(act.divider(), 0, MATCH, 1)
            val exactOk = Scheduler.canScheduleExact(act)
            c3.put(permRow("المنبهات الدقيقة (اختياري)", exactOk, "فتح") { Perms.requestExactAlarms(act) })
        }

        c3.put(act.divider(), 0, MATCH, 1)
        c3.put(settingRow("تشغيل تلقائي / خلفية (OPPO)", act.goldButton("فتح", false) { Perms.openOppoAutostart(act) }))
        c3.put(
            act.label(
                "هواتف OPPO (ColorOS) توقف التطبيقات في الخلفية بشدة. لضمان الأذان: " +
                    "① فعّل «التشغيل التلقائي» للتطبيق. ② من البطارية اختر «السماح بالنشاط في الخلفية». " +
                    "③ ثبّت التطبيق في شاشة التطبيقات الأخيرة (قفل). ④ لا تُغلقه بالتمرير ولا بـ «إيقاف إجباري».",
                12f, Colors.MUTED
            ),
            6
        )
        body.put(c3)

        body.addView(act.sectionTitle("أدوات"))
        val c4 = act.card()
        c4.put(settingRow("إسكات الأذان الجاري الآن", act.goldButton("إيقاف", false) { AdhanService.stop(act) }))
        body.put(c4)

        body.addView(act.sectionTitle("عن التطبيق"))
        val c5 = act.card()
        c5.put(
            act.label(
                "«نور الصلاة» تطبيق أندرويد أصلي (Kotlin). لا يطلب إذن الإنترنت ولا يرسل أي بيانات، " +
                    "وكل الإعدادات محفوظة على هاتفك فقط. الإصدار 1.0.0.\n" +
                    "نص المصحف (الرسم العثماني): مشروع Tanzil.net، بترخيص CC BY 3.0، ويُضاف عند البناء. " +
                    "الأذكار من كتب الأذكار المشهورة (مثل حصن المسلم) وتحتاج مراجعتك قبل الحفظ.",
                13f, Colors.MUTED
            )
        )
        body.put(c5)
    }

    private fun stepper(value: Int, unit: String, onDelta: (Int) -> Unit): LinearLayout {
        val box = act.hbox()
        box.put(act.goldButton("−", false) { onDelta(-1) }, 0, WRAP, WRAP)
        val t = act.label((if (value > 0) "+" else "") + value + " " + unit, 14f, Colors.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(act.dp(10), 0, act.dp(10), 0)
        box.put(t, 0, WRAP, WRAP)
        box.put(act.goldButton("+", false) { onDelta(1) }, 0, WRAP, WRAP)
        return box
    }

    private fun permRow(title: String, ok: Boolean, actionLabel: String, onClick: () -> Unit): LinearLayout {
        val box = act.hbox()
        box.setPadding(0, act.dp(8), 0, act.dp(8))
        val col = act.vbox()
        col.put(act.label(title, 15f, Colors.TEXT))
        col.put(act.label(if (ok) "✓ مفعّل" else "✗ غير مفعّل", 12f, if (ok) Colors.OK else Colors.WARN, true), 2)
        box.put(col, 0, 0, WRAP, 1f)
        if (!ok) {
            val p = LinearLayout.LayoutParams(WRAP, WRAP)
            p.marginStart = act.dp(10)
            box.addView(act.goldButton(actionLabel, true) { onClick() }, p)
        }
        return box
    }

    private fun prayerCard(p: Prayer): LinearLayout {
        val idx = p.ordinal
        val c = act.card()

        val head = act.hbox()
        head.put(act.label(p.nameAr, 19f, Colors.GOLD, true), 0, 0, WRAP, 1f)
        head.put(act.label("تشغيل الأذان", 13f, Colors.MUTED), 0, WRAP, WRAP)
        val sw = act.goldSwitch(prefs.adhanOn(idx)) { v ->
            prefs.setAdhanOn(idx, v)
            reschedule()
        }
        val swp = LinearLayout.LayoutParams(WRAP, WRAP)
        swp.marginStart = act.dp(10)
        head.addView(sw, swp)
        c.put(head)

        c.put(act.divider(), 8, MATCH, 1)
        c.put(settingRow("الصوت: " + soundLabel(idx), act.goldButton("تغيير", false) { pickSound(idx) }))

        val btns = act.hbox()
        btns.put(act.goldButton("تجربة الصوت", false) {
            AdhanService.preview(act, idx)
            Toast.makeText(act, "يعمل الآن. لإسكاته: «إيقاف» من قسم الأدوات أو من الإشعار.", Toast.LENGTH_SHORT).show()
        }, 0, 0, WRAP, 1f)
        val tb = act.goldButton("اختبار بعد 15 ثانية", false) {
            Scheduler.scheduleTest(act, idx, 15)
            Toast.makeText(
                act,
                "سيُشغَّل الأذان بعد 15 ثانية عبر المنبه الحقيقي. اقفل الشاشة واترك التطبيق في الخلفية لتتأكد.",
                Toast.LENGTH_LONG
            ).show()
        }
        val tp = LinearLayout.LayoutParams(0, WRAP, 1f)
        tp.marginStart = act.dp(8)
        btns.addView(tb, tp)
        c.put(btns, 6)

        c.put(settingRow("تعديل الوقت يدويًا", stepper(prefs.offset(idx), "د") { delta ->
            prefs.setOffset(idx, prefs.offset(idx) + delta)
            reschedule()
            refresh()
        }))
        return c
    }

    // ---------------- الأصوات ----------------

    private fun soundLabel(idx: Int): String {
        val type = prefs.soundType(idx)
        return when {
            type == "system" -> "نغمة المنبه للنظام"
            type == "file" -> prefs.soundName(idx).ifEmpty { "ملف مخصص" }
            type.startsWith("raw:") -> type.removePrefix("raw:").removePrefix("adhan_").replace('_', ' ')
            else -> "نغمة التطبيق"
        }
    }

    private fun pickSound(idx: Int) {
        val labels = ArrayList<String>()
        val types = ArrayList<String>()
        labels.add("نغمة التطبيق (جرس هادئ، ليست أذانًا)")
        types.add("chime")
        labels.add("نغمة المنبه الافتراضية للنظام")
        types.add("system")
        for (f in R.raw::class.java.fields) {
            if (f.name.startsWith("adhan_")) {
                labels.add("أذان: " + f.name.removePrefix("adhan_").replace('_', ' '))
                types.add("raw:" + f.name)
            }
        }
        labels.add("اختيار ملف صوتي من هاتفك…")
        types.add("pick")

        val cur = prefs.soundType(idx)
        var checked = types.indexOf(cur)
        if (checked < 0) checked = types.size - 1

        act.dialogBuilder()
            .setTitle("صوت أذان " + Prayer.fromIndex(idx).nameAr)
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                d.dismiss()
                val t = types[which]
                if (t == "pick") {
                    act.pickAudioFor(idx)
                } else {
                    prefs.setSoundType(idx, t)
                    prefs.setSoundName(idx, "")
                    refresh()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun pickMethod() {
        val names = Methods.all.map { it.nameAr }.toTypedArray()
        val checked = Methods.all.indexOfFirst { it.id == prefs.methodId }
        act.dialogBuilder()
            .setTitle("طريقة حساب المواقيت")
            .setSingleChoiceItems(names, checked) { d, which ->
                prefs.methodId = Methods.all[which].id
                reschedule()
                d.dismiss()
                refresh()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun pickPre() {
        val values = intArrayOf(0, 5, 10, 15, 20, 30)
        val names = values.map { if (it == 0) "معطّل" else "$it دقيقة" }.toTypedArray()
        val checked = values.indexOf(prefs.preMinutes)
        act.dialogBuilder()
            .setTitle("التنبيه قبل الصلاة")
            .setSingleChoiceItems(names, checked) { d, which ->
                prefs.preMinutes = values[which]
                reschedule()
                d.dismiss()
                refresh()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
