package com.noorsalat.app

import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

class HomeScreen(private val act: MainActivity) : MainActivity.Screen {

    private val scroll = ScrollView(act)
    private val body = act.vbox(16)
    override val root: View get() = scroll

    private val handler = Handler(Looper.getMainLooper())
    private var binding = false

    private lateinit var cityBtn: TextView
    private lateinit var gregText: TextView
    private lateinit var hijriText: TextView
    private lateinit var nextName: TextView
    private lateinit var nextTime: TextView
    private lateinit var countdown: TextView
    private lateinit var statusBox: LinearLayout
    private lateinit var methodNote: TextView
    private lateinit var sunriseTime: TextView
    private val rowTimes = ArrayList<TextView>()
    private val rowSwitches = ArrayList<Switch>()
    private val rowBoxes = ArrayList<LinearLayout>()

    private var times: DayTimes? = null
    private var nextAt = 0L

    private val tick = object : Runnable {
        override fun run() {
            updateCountdown()
            handler.postDelayed(this, 1000L)
        }
    }

    init {
        scroll.isFillViewport = true
        scroll.addView(body)
        build()
    }

    private fun build() {
        // ---- الترويسة ----
        val header = act.hbox()
        header.put(act.label("نور الصلاة", 26f, Colors.GOLD, true), 0, 0, WRAP, 1f)
        cityBtn = act.goldButton("", false) { act.pickCity { refresh() } }
        header.put(cityBtn, 0, WRAP, WRAP)
        body.put(header)

        gregText = act.label("", 15f, Colors.TEXT)
        hijriText = act.label("", 14f, Colors.MUTED)
        body.put(gregText, 6)
        body.put(hijriText, 2)

        // ---- بطاقة الصلاة القادمة ----
        val nextCard = act.vbox(18)
        nextCard.background = rounded(Colors.CARD_HI, act.dp(20).toFloat(), Colors.GOLD, act.dp(1))
        nextCard.put(act.label("الصلاة القادمة", 14f, Colors.MUTED))
        nextName = act.label("", 34f, Colors.GOLD, true)
        nextCard.put(nextName, 4)
        nextTime = act.label("", 20f, Colors.TEXT)
        nextCard.put(nextTime, 2)
        countdown = act.label("", 38f, Colors.TEXT, true)
        countdown.gravity = Gravity.CENTER
        nextCard.put(countdown, 10)
        nextCard.put(act.label("المتبقي على دخول الوقت", 12f, Colors.MUTED).also { it.gravity = Gravity.CENTER })
        body.put(nextCard, 16)

        // ---- حالة الأذونات (ديناميكية) ----
        statusBox = act.vbox()
        body.put(statusBox, 12)

        // ---- قائمة الصلوات ----
        val list = act.card()
        for (p in Prayer.values()) {
            val idx = p.ordinal
            val row = act.hbox()
            row.setPadding(act.dp(8), act.dp(10), act.dp(8), act.dp(10))
            row.put(act.label(p.nameAr, 19f, Colors.TEXT, true), 0, 0, WRAP, 1f)
            val t = act.label("", 20f, Colors.GOLD, true)
            row.put(t, 0, WRAP, WRAP)
            val sw = act.goldSwitch(prefsOn(idx)) { v ->
                if (!binding) {
                    act.prefs.setAdhanOn(idx, v)
                    Scheduler.rescheduleAll(act)
                }
            }
            val swp = LinearLayout.LayoutParams(WRAP, WRAP)
            swp.marginStart = act.dp(14)
            row.addView(sw, swp)
            rowTimes.add(t)
            rowSwitches.add(sw)
            rowBoxes.add(row)
            list.put(row)
            if (p == Prayer.FAJR) {
                val sr = act.hbox()
                sr.setPadding(act.dp(8), act.dp(4), act.dp(8), act.dp(10))
                sr.put(act.label("الشروق (ليس وقت صلاة)", 14f, Colors.MUTED), 0, 0, WRAP, 1f)
                sunriseTime = act.label("", 15f, Colors.MUTED)
                sr.put(sunriseTime, 0, WRAP, WRAP)
                list.put(sr)
            }
            if (p != Prayer.ISHA) list.put(act.divider(), 0, MATCH, 1)
        }
        body.put(list, 12)

        methodNote = act.label("", 12f, Colors.MUTED)
        body.put(methodNote, 12)
        body.put(act.label("المفتاح بجانب كل صلاة يشغّل الأذان أو يوقفه لتلك الصلاة. اختيار الصوت في تبويب الإعدادات.", 12f, Colors.MUTED), 6)
    }

    private fun prefsOn(i: Int): Boolean = act.prefs.adhanOn(i)

    override fun onShow() {
        refresh()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onHide() {
        handler.removeCallbacks(tick)
    }

    fun refresh() {
        val prefs = act.prefs
        val city = Cities.byId(prefs.cityId)
        cityBtn.text = "📍 " + city.nameAr

        val today = LocalDate.now(Cities.ZONE)
        val t = TimesProvider.get(act, today)
        times = t

        gregText.text = gregorian(today)
        hijriText.text = hijri(today, prefs.hijriAdjust)

        binding = true
        for (p in Prayer.values()) {
            rowTimes[p.ordinal].text = Util.hm(t.of(p))
            rowSwitches[p.ordinal].isChecked = prefs.adhanOn(p.ordinal)
        }
        binding = false
        sunriseTime.text = Util.hm(t.sunrise)

        val m = Methods.byId(prefs.methodId)
        methodNote.text = "طريقة الحساب: " + m.nameAr +
            (if (prefs.hanafi) " — العصر بالمذهب الحنفي" else "") +
            ". الحساب فلكي محلي دون إنترنت، وقد يختلف دقيقة أو دقيقتين عن الجداول الرسمية؛ يمكنك ضبط الدقائق لكل صلاة من الإعدادات."

        computeNext(today, t)
        updateStatus()
        updateCountdown()
    }

    private fun computeNext(today: LocalDate, t: DayTimes) {
        val now = System.currentTimeMillis()
        var next: Prayer? = null
        var ms = 0L
        for (p in Prayer.values()) {
            val x = t.millis(p)
            if (x > now) {
                next = p
                ms = x
                break
            }
        }
        var highlightToday = true
        if (next == null) {
            val tm = TimesProvider.get(act, today.plusDays(1))
            next = Prayer.FAJR
            ms = tm.millis(Prayer.FAJR)
            highlightToday = false
        }
        nextAt = ms
        nextName.text = next.nameAr + (if (highlightToday) "" else " (غدًا)")
        nextTime.text = Util.hm(ms)

        for (i in rowBoxes.indices) {
            val hi = highlightToday && i == next.ordinal
            rowBoxes[i].background = if (hi) rounded(Colors.CARD_HI, act.dp(12).toFloat()) else null
        }
    }

    private fun updateCountdown() {
        if (nextAt == 0L) {
            countdown.text = "--:--:--"
            return
        }
        val left = nextAt - System.currentTimeMillis()
        if (left <= 0L) {
            // دخل الوقت (أو تغيّر اليوم): أعد حساب الصلاة القادمة
            nextAt = 0L
            refresh()
            return
        }
        countdown.text = Util.countdown(left)
    }

    private fun updateStatus() {
        statusBox.removeAllViews()
        val items = ArrayList<Triple<String, String, () -> Unit>>()

        if (!Perms.notificationsEnabled(act)) {
            val go: () -> Unit = { Perms.requestNotifications(act, act.prefs) }
            items.add(Triple("الإشعارات غير مفعّلة، فلن تظهر تنبيهات الصلاة.", "تفعيل", go))
        }
        if (!Perms.batteryExempt(act)) {
            val go: () -> Unit = { Perms.requestBatteryExemption(act) }
            items.add(Triple("توفير البطارية قد يمنع الأذان في الخلفية.", "استثناء التطبيق", go))
        }
        if (Perms.isOppoFamily()) {
            val go: () -> Unit = { Perms.openOppoAutostart(act) }
            items.add(Triple("هاتف OPPO: فعّل «التشغيل التلقائي» و«النشاط في الخلفية» للتطبيق.", "فتح الإعدادات", go))
        }

        for (item in items) {
            val c = act.hbox()
            c.setPadding(act.dp(12), act.dp(10), act.dp(12), act.dp(10))
            c.background = rounded(Colors.CARD, act.dp(14).toFloat(), Colors.WARN, act.dp(1))
            c.put(act.label(item.first, 13f, Colors.TEXT), 0, 0, WRAP, 1f)
            val b = act.goldButton(item.second, true) { item.third() }
            val bp = LinearLayout.LayoutParams(WRAP, WRAP)
            bp.marginStart = act.dp(10)
            c.addView(b, bp)
            statusBox.put(c, 8)
        }
    }

    private val weekdays = arrayOf("الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")
    private val monthsTn = arrayOf(
        "جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان",
        "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
    )
    private val monthsHijri = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    private fun gregorian(d: LocalDate): String =
        weekdays[d.dayOfWeek.value - 1] + " " + d.dayOfMonth + " " + monthsTn[d.monthValue - 1] + " " + d.year

    private fun hijri(d: LocalDate, adjust: Int): String {
        return try {
            val h = HijrahDate.from(d.plusDays(adjust.toLong()))
            val day = h.get(ChronoField.DAY_OF_MONTH)
            val month = h.get(ChronoField.MONTH_OF_YEAR)
            val year = h.get(ChronoField.YEAR)
            day.toString() + " " + monthsHijri[month - 1] + " " + year + " هـ"
        } catch (e: Exception) {
            ""
        }
    }
}
