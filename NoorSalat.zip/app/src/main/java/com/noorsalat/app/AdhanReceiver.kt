package com.noorsalat.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * يستقبل المنبه عند دخول الوقت (أو قبله). المنطق:
 *  - تنبيه مسبق: إشعار فقط.
 *  - دخول الوقت: إن كان الأذان مفعّلًا لتلك الصلاة نبدأ خدمة الأذان الأمامية، وإلا نعرض إشعارًا فقط.
 *  - إن وصل المنبه متأخرًا جدًا (الهاتف كان مطفأ مثلًا) فلا نشغّل الأذان بعد فوات وقته.
 * وفي كل الأحوال نعيد جدولة المنبهات التالية.
 */
class AdhanReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        try {
            if (intent.action == Scheduler.ACTION_ALARM) handleAlarm(app, intent)
        } finally {
            Scheduler.rescheduleAll(app)
        }
    }

    private fun handleAlarm(app: Context, intent: Intent) {
        val idx = intent.getIntExtra(Scheduler.EXTRA_PRAYER, -1)
        if (idx < 0 || idx > 4) return
        val kind = intent.getIntExtra(Scheduler.EXTRA_KIND, Scheduler.KIND_TIME)
        val at = intent.getLongExtra(Scheduler.EXTRA_AT, 0L)
        val test = intent.getBooleanExtra(Scheduler.EXTRA_TEST, false)
        val prayer = Prayer.fromIndex(idx)
        val prefs = Prefs(app)

        val lateMs = if (at > 0L) System.currentTimeMillis() - at else 0L
        val maxLate = if (kind == Scheduler.KIND_PRE) PRE_MAX_LATE_MS else TIME_MAX_LATE_MS
        if (!test && lateMs > maxLate) return // فات الوقت: لا نزعج المستخدم

        if (kind == Scheduler.KIND_PRE) {
            val minutes = prefs.preMinutes
            Notifier.showPre(app, prayer, minutes, Util.hm(at + minutes * 60_000L))
            return
        }

        if (test || prefs.adhanOn(idx)) {
            try {
                val svc = Intent(app, AdhanService::class.java)
                svc.putExtra(Scheduler.EXTRA_PRAYER, idx)
                app.startForegroundService(svc)
            } catch (e: Exception) {
                // قيود النظام على بدء الخدمات من الخلفية: نكتفي بإشعار بصوت النظام
                Notifier.showTime(app, prayer)
            }
        } else if (prefs.notifyAtTime) {
            Notifier.showTime(app, prayer)
        }
    }

    companion object {
        private const val TIME_MAX_LATE_MS = 10 * 60_000L
        private const val PRE_MAX_LATE_MS = 5 * 60_000L
    }
}
