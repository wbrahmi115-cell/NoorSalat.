package com.noorsalat.app

import java.time.ZoneId

data class City(val id: String, val nameAr: String, val lat: Double, val lng: Double)

object Cities {
    const val DEFAULT_ID = "tunis"

    /** توقيت تونس (UTC+1 دون توقيت صيفي حاليًا). يُقرأ من قاعدة بيانات المناطق الزمنية في النظام. */
    val ZONE: ZoneId = ZoneId.of("Africa/Tunis")

    val all: List<City> = listOf(
        City("tunis", "تونس", 36.8065, 10.1815),
        City("ariana", "أريانة", 36.8625, 10.1956),
        City("benarous", "بن عروس", 36.7533, 10.2189),
        City("manouba", "منوبة", 36.8081, 10.0972),
        City("nabeul", "نابل", 36.4561, 10.7376),
        City("hammamet", "الحمامات", 36.4000, 10.6167),
        City("kelibia", "قليبية", 36.8476, 11.0939),
        City("zaghouan", "زغوان", 36.4029, 10.1429),
        City("bizerte", "بنزرت", 37.2744, 9.8739),
        City("beja", "باجة", 36.7256, 9.1817),
        City("jendouba", "جندوبة", 36.5011, 8.7803),
        City("tabarka", "طبرقة", 36.9544, 8.7580),
        City("kef", "الكاف", 36.1742, 8.7049),
        City("siliana", "سليانة", 36.0849, 9.3708),
        City("sousse", "سوسة", 35.8256, 10.6369),
        City("monastir", "المنستير", 35.7643, 10.8113),
        City("mahdia", "المهدية", 35.5047, 11.0622),
        City("eljem", "الجم", 35.2964, 10.7066),
        City("sfax", "صفاقس", 34.7406, 10.7603),
        City("kairouan", "القيروان", 35.6781, 10.0963),
        City("kasserine", "القصرين", 35.1676, 8.8365),
        City("sidibouzid", "سيدي بوزيد", 35.0382, 9.4858),
        City("gabes", "قابس", 33.8815, 10.0982),
        City("medenine", "مدنين", 33.3549, 10.5055),
        City("djerba", "جربة (حومة السوق)", 33.8750, 10.8575),
        City("zarzis", "جرجيس", 33.5036, 11.1122),
        City("tataouine", "تطاوين", 32.9297, 10.4518),
        City("gafsa", "قفصة", 34.4250, 8.7842),
        City("tozeur", "توزر", 33.9197, 8.1335),
        City("nefta", "نفطة", 33.8736, 7.8786),
        City("kebili", "قبلي", 33.7044, 8.9690),
        City("douz", "دوز", 33.4575, 9.0206)
    )

    fun byId(id: String): City = all.firstOrNull { it.id == id } ?: all[0]
}
