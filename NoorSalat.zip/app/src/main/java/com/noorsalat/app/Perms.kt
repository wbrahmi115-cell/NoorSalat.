package com.noorsalat.app

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast

/** أذونات وإعدادات النظام التي يحتاجها الأذان في الخلفية، مع مسارات خاصة بهواتف OPPO/ColorOS. */
object Perms {
    const val REQ_NOTIFICATIONS = 11

    // نوافذ "التشغيل التلقائي / إدارة البطارية" المعروفة في ColorOS (تختلف بين الإصدارات).
    private val OPPO_SCREENS = listOf(
        "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
        "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
        "com.coloros.oppoguardelf" to "com.coloros.powermanager.fuelgauge.PowerUsageModelActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.FakeActivity"
    )

    fun notificationsEnabled(ctx: Context): Boolean {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.areNotificationsEnabled()
    }

    fun batteryExempt(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(ctx.packageName)
    }

    fun isOppoFamily(): Boolean {
        val m = Build.MANUFACTURER.lowercase()
        return m.contains("oppo") || m.contains("realme") || m.contains("oneplus")
    }

    /** يطلب إذن الإشعارات (Android 13+)، وإن سبق طلبه يفتح إعدادات الإشعارات للتطبيق. */
    fun requestNotifications(act: Activity, prefs: Prefs) {
        if (Build.VERSION.SDK_INT >= 33 && !prefs.notifAsked) {
            prefs.notifAsked = true
            act.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
        } else {
            openNotificationSettings(act)
        }
    }

    fun openNotificationSettings(act: Activity) {
        try {
            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            i.putExtra(Settings.EXTRA_APP_PACKAGE, act.packageName)
            act.startActivity(i)
        } catch (e: Exception) {
            openAppDetails(act)
        }
    }

    fun requestBatteryExemption(act: Activity) {
        try {
            val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            i.data = Uri.parse("package:" + act.packageName)
            act.startActivity(i)
        } catch (e: Exception) {
            try {
                act.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                openAppDetails(act)
            }
        }
    }

    fun requestExactAlarms(act: Activity) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val i = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                i.data = Uri.parse("package:" + act.packageName)
                act.startActivity(i)
            } else {
                openAppDetails(act)
            }
        } catch (e: Exception) {
            openAppDetails(act)
        }
    }

    fun openAppDetails(act: Activity) {
        try {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:" + act.packageName)
            act.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(act, "تعذّر فتح إعدادات التطبيق", Toast.LENGTH_LONG).show()
        }
    }

    /** يحاول فتح نافذة التشغيل التلقائي في OPPO؛ وإن لم تُفتح يعرض الخطوات اليدوية. */
    fun openOppoAutostart(act: Activity) {
        for ((pkg, cls) in OPPO_SCREENS) {
            try {
                val i = Intent()
                i.component = ComponentName(pkg, cls)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                act.startActivity(i)
                return
            } catch (e: Exception) {
                // جرّب النافذة التالية
            }
        }
        openAppDetails(act)
        Toast.makeText(
            act,
            "افتح: البطارية ← استخدام البطارية للتطبيق ← نور الصلاة، وفعّل «السماح بالنشاط في الخلفية» و«التشغيل التلقائي»",
            Toast.LENGTH_LONG
        ).show()
    }
}
