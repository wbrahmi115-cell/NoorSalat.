package com.noorsalat.app

import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.Gravity
import android.view.View
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class QiblaScreen(private val act: MainActivity) : MainActivity.Screen, SensorEventListener {

    private val scroll = ScrollView(act)
    private val body = act.vbox(16)
    override val root: View get() = scroll

    private val sm = act.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rotationSensor: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val accelSensor: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val magnetSensor: Sensor? = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    private val compass = CompassView(act)
    private lateinit var titleText: TextView
    private lateinit var infoText: TextView
    private lateinit var statusText: TextView

    private var qiblaDeg = 0.0
    private var declination = 0f
    private var heading = 0f
    private var hasHeading = false

    private val rotMat = FloatArray(9)
    private val orient = FloatArray(3)
    private val gravity = FloatArray(3)
    private val geomag = FloatArray(3)
    private var hasGravity = false
    private var hasGeomag = false

    init {
        scroll.addView(body)
        body.put(act.label("اتجاه القبلة", 26f, Colors.GOLD, true))
        titleText = act.label("", 14f, Colors.MUTED)
        body.put(titleText, 4)
        body.put(compass, 16, MATCH, WRAP)
        statusText = act.label("", 16f, Colors.TEXT, true)
        statusText.gravity = Gravity.CENTER
        body.put(statusText, 12)
        infoText = act.label("", 13f, Colors.MUTED)
        body.put(infoText, 12)
        body.put(
            act.label(
                "للحصول على أدق نتيجة: ضع الهاتف مسطّحًا بعيدًا عن المعادن والمغناطيس، " +
                    "وإن ظهر تنبيه المعايرة فحرّك الهاتف في الهواء على شكل رقم 8. " +
                    "الاتجاه محسوب من إحداثيات مدينتك المختارة دون الحاجة لإذن الموقع.",
                13f, Colors.MUTED
            ),
            12
        )
    }

    override fun onShow() {
        val city = Cities.byId(act.prefs.cityId)
        qiblaDeg = Qibla.bearing(city.lat, city.lng)
        val dist = Qibla.distanceKm(city.lat, city.lng)
        declination = GeomagneticField(city.lat.toFloat(), city.lng.toFloat(), 0f, System.currentTimeMillis()).declination
        compass.setQibla(qiblaDeg.toFloat())
        titleText.text = "من " + city.nameAr
        infoText.text = String.format(
            Locale.ENGLISH,
            "زاوية القبلة: %.1f° من الشمال الحقيقي (باتجاه عقارب الساعة)\nالمسافة إلى الكعبة: %,d كم تقريبًا",
            qiblaDeg, Math.round(dist)
        )

        hasHeading = false
        hasGravity = false
        hasGeomag = false
        if (rotationSensor != null) {
            sm.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_UI)
            statusText.text = "حرّك الهاتف قليلًا..."
        } else if (accelSensor != null && magnetSensor != null) {
            sm.registerListener(this, accelSensor, SensorManager.SENSOR_DELAY_UI)
            sm.registerListener(this, magnetSensor, SensorManager.SENSOR_DELAY_UI)
            statusText.text = "حرّك الهاتف قليلًا..."
        } else {
            statusText.text = "لا يحتوي هاتفك على مستشعر بوصلة. الزاوية المعروضة أعلاه تُستخدم مع بوصلة خارجية."
            statusText.setTextColor(Colors.WARN)
        }
    }

    override fun onHide() {
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        var azimuth: Float? = null
        when (e.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR -> {
                val v = e.values.copyOf(minOf(e.values.size, 4))
                SensorManager.getRotationMatrixFromVector(rotMat, v)
                SensorManager.getOrientation(rotMat, orient)
                azimuth = Math.toDegrees(orient[0].toDouble()).toFloat()
            }
            Sensor.TYPE_ACCELEROMETER -> {
                lowPass(e.values, gravity, hasGravity)
                hasGravity = true
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                lowPass(e.values, geomag, hasGeomag)
                hasGeomag = true
            }
        }
        if (e.sensor.type != Sensor.TYPE_ROTATION_VECTOR && hasGravity && hasGeomag) {
            if (SensorManager.getRotationMatrix(rotMat, null, gravity, geomag)) {
                SensorManager.getOrientation(rotMat, orient)
                azimuth = Math.toDegrees(orient[0].toDouble()).toFloat()
            }
        }
        if (azimuth == null) return

        val trueHeading = ((azimuth + declination) % 360f + 360f) % 360f
        heading = if (!hasHeading) trueHeading else smooth(heading, trueHeading, 0.18f)
        hasHeading = true
        compass.setHeading(heading)

        if (compass.isAligned()) {
            statusText.text = "✓ أنت تواجه القبلة"
            statusText.setTextColor(Colors.OK)
        } else {
            val d = ((qiblaDeg.toFloat() - heading + 540f) % 360f) - 180f
            statusText.text = if (d > 0) "در نحو اليمين " + Math.round(d) + "°" else "در نحو اليسار " + Math.round(-d) + "°"
            statusText.setTextColor(Colors.TEXT)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        if (accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW && hasHeading) {
            infoText.text = infoText.text.toString().substringBefore("\n⚠") +
                "\n⚠ دقة المستشعر منخفضة: عايِر البوصلة بتحريك الهاتف على شكل 8."
        }
    }

    private fun lowPass(input: FloatArray, output: FloatArray, initialized: Boolean) {
        for (i in 0 until 3) {
            output[i] = if (initialized) output[i] + 0.15f * (input[i] - output[i]) else input[i]
        }
    }

    private fun smooth(cur: Float, target: Float, a: Float): Float {
        val d = ((target - cur + 540f) % 360f) - 180f
        return ((cur + d * a) % 360f + 360f) % 360f
    }
}
