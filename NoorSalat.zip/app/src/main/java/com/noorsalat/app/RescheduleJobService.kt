package com.noorsalat.app

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context

/**
 * شبكة أمان: مهمة دورية (كل 6 ساعات تقريبًا) تعيد جدولة المنبهات.
 * إن ألغى النظام منبهًا لأي سبب فستعيده هذه المهمة دون الحاجة لفتح التطبيق.
 */
class RescheduleJobService : JobService() {

    override fun onStartJob(params: JobParameters?): Boolean {
        Scheduler.rescheduleAll(applicationContext)
        return false
    }

    override fun onStopJob(params: JobParameters?): Boolean = false

    companion object {
        private const val JOB_ID = 7001

        fun ensureScheduled(ctx: Context) {
            try {
                val js = ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
                if (js.getPendingJob(JOB_ID) != null) return
                val info = JobInfo.Builder(JOB_ID, ComponentName(ctx, RescheduleJobService::class.java))
                    .setPeriodic(6L * 60L * 60L * 1000L)
                    .setPersisted(true)
                    .build()
                js.schedule(info)
            } catch (e: Exception) {
                // غير حرج: المنبهات تُعاد جدولتها أيضًا عند إطلاق كل منبه وعند فتح التطبيق
            }
        }
    }
}
