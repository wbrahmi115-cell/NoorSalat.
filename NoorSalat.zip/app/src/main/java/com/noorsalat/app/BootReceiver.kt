package com.noorsalat.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** يعيد جدولة الأذان بعد إعادة تشغيل الهاتف أو تحديث التطبيق أو تغيير الوقت/المنطقة الزمنية. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val relevant = action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == "com.htc.intent.action.QUICKBOOT_POWERON"
        if (!relevant) return

        val app = context.applicationContext
        Notifier.ensureChannels(app)
        Scheduler.rescheduleAll(app)
        RescheduleJobService.ensureScheduled(app)
    }
}
