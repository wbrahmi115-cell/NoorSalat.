package com.noorsalat.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.LocalDate

/**
 * جدولة منبهات الأذان والتنبيهات المسبقة عبر AlarmManager.
 *
 * نجدول فقط "الحدث التالي" لكل صلاة (وكل نوع)، وعند إطلاقه يعيد المستقبِل جدولة الجميع.
 * فإذا تعطّل أحد المنبهات يبقى الباقي يعمل، وتصلحه المهمة الدورية أو فتح التطبيق.
 */
object Scheduler {
    const val ACTION_ALARM = "com.noorsalat.app.action.ALARM"
    const val EXTRA_PRAYER = "prayer"
    const val EXTRA_KIND = "kind"
    const val EXTRA_AT = "at"
    const val EXTRA_TEST = "test"

    const val KIND_PRE = 0
    const val KIND_TIME = 1

    private const val TEST_CODE = 900
    private const val PI_FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    private fun code(kind: Int, prayer: Int): Int = kind * 10 + prayer + 1

    private fun alarmIntent(ctx: Context, kind: Int, prayer: Int, at: Long, test: Boolean): Intent {
        val i = Intent(ctx, AdhanReceiver::class.java)
        i.action = ACTION_ALARM
        i.putExtra(EXTRA_KIND, kind)
        i.putExtra(EXTRA_PRAYER, prayer)
        i.putExtra(EXTRA_AT, at)
        i.putExtra(EXTRA_TEST, test)
        return i
    }

    @Synchronized
    fun rescheduleAll(ctx: Context) {
        val app = ctx.applicationContext
        val prefs = Prefs(app)
        val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        val today = LocalDate.now(Cities.ZONE)
        val days = (0..2).map { TimesProvider.get(app, today.plusDays(it.toLong())) }
        val pre = prefs.preMinutes

        for (p in Prayer.values()) {
            val idx = p.ordinal

            // منبه دخول الوقت (أذان و/أو إشعار)
            val timeWanted = prefs.adhanOn(idx) || prefs.notifyAtTime
            val at = days.map { it.millis(p) }.firstOrNull { it > now + 1000L }
            if (timeWanted && at != null) {
                val pi = PendingIntent.getBroadcast(app, code(KIND_TIME, idx), alarmIntent(app, KIND_TIME, idx, at, false), PI_FLAGS)
                scheduleOne(app, am, pi, at, prefs.useAlarmClock)
            } else {
                cancel(app, am, KIND_TIME, idx)
            }

            // تنبيه قبل الصلاة
            if (pre > 0) {
                val preAt = days.map { it.millis(p) - pre * 60_000L }.firstOrNull { it > now + 1000L }
                if (preAt != null) {
                    val pi = PendingIntent.getBroadcast(app, code(KIND_PRE, idx), alarmIntent(app, KIND_PRE, idx, preAt, false), PI_FLAGS)
                    scheduleOne(app, am, pi, preAt, false)
                } else {
                    cancel(app, am, KIND_PRE, idx)
                }
            } else {
                cancel(app, am, KIND_PRE, idx)
            }
        }
    }

    /** جدولة اختبار حقيقي يمر بنفس مسار الأذان الفعلي (منبه ← مستقبِل ← خدمة). */
    fun scheduleTest(ctx: Context, prayer: Int, seconds: Int): Long {
        val app = ctx.applicationContext
        val prefs = Prefs(app)
        val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = System.currentTimeMillis() + seconds * 1000L
        val pi = PendingIntent.getBroadcast(app, TEST_CODE, alarmIntent(app, KIND_TIME, prayer, at, true), PI_FLAGS)
        scheduleOne(app, am, pi, at, prefs.useAlarmClock)
        return at
    }

    private fun scheduleOne(ctx: Context, am: AlarmManager, pi: PendingIntent, at: Long, useAlarmClock: Boolean) {
        try {
            if (useAlarmClock) {
                val show = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PI_FLAGS)
                am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
            } else if (canScheduleExact(ctx)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun cancel(ctx: Context, am: AlarmManager, kind: Int, prayer: Int) {
        val i = Intent(ctx, AdhanReceiver::class.java)
        i.action = ACTION_ALARM
        val existing = PendingIntent.getBroadcast(
            ctx, code(kind, prayer), i,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (existing != null) {
            am.cancel(existing)
            existing.cancel()
        }
    }

    fun canScheduleExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }
}
