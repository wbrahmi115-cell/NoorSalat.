package com.noorsalat.app

import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

object Util {
    private val HM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm", Locale.ENGLISH)

    fun hm(z: ZonedDateTime): String = z.format(HM)

    fun hm(ms: Long): String = Instant.ofEpochMilli(ms).atZone(Cities.ZONE).format(HM)

    /** تحويل رقم إلى أرقام هندية عربية (٠١٢٣...) لعرض أرقام الآيات. */
    fun arabicIndic(n: Int): String {
        val digits = "٠١٢٣٤٥٦٧٨٩"
        val sb = StringBuilder()
        for (c in n.toString()) {
            sb.append(if (c in '0'..'9') digits[c - '0'] else c)
        }
        return sb.toString()
    }

    fun countdown(ms: Long): String {
        val total = if (ms < 0) 0L else ms / 1000L
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return String.format(Locale.ENGLISH, "%02d:%02d:%02d", h, m, s)
    }
}
