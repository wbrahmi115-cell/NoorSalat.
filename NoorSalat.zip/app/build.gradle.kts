plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// مفتاح توقيع ثابت (غير سري، للاستخدام الشخصي) كي تُثبَّت التحديثات فوق النسخة السابقة
// دون حذف التطبيق. للنشر العام أنشئ مفتاحك الخاص.
val noorKeystore = rootProject.file("keystore/noor.jks")

android {
    namespace = "com.noorsalat.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.noorsalat.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    signingConfigs {
        create("noor") {
            if (noorKeystore.exists()) {
                storeFile = noorKeystore
                storePassword = "noorsalat"
                keyAlias = "noor"
                keyPassword = "noorsalat"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (noorKeystore.exists()) {
                signingConfigs.getByName("noor")
            } else {
                signingConfigs.getByName("debug")
            }
        }
        debug {
            if (noorKeystore.exists()) {
                signingConfig = signingConfigs.getByName("noor")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

// لا توجد أي اعتماديات خارجية عمدًا: Kotlin وAndroid SDK فقط.
dependencies {
}
