#!/usr/bin/env python3
"""
يجلب نص المصحف (الرسم العثماني) أثناء البناء ويكتبه في app/src/main/assets/quran_full.json
بالشكل: مصفوفة من 114 مصفوفة، كل واحدة فيها آيات السورة (نصوص).

- المصدر: واجهة alquran.cloud المجانية (لا تحتاج مفتاحًا)، ونصها من مشروع Tanzil.net (CC BY 3.0).
- يتحقق من أن عدد آيات كل سورة يطابق الجدول COUNTS في QuranRepo.kt (مجموعها 6236).
- يفصل البسملة عن الآية الأولى (تعرضها الواجهة كعنوان) عدا الفاتحة (البسملة آيتها الأولى) والتوبة.
- إن فشل أي شيء يخرج برمز خطأ ولا يكتب ملفًا ناقصًا، فيبقى التطبيق على النسخة المضمّنة القصيرة.

يعمل بمكتبة بايثون القياسية فقط.
"""
import json
import pathlib
import re
import sys
import time
import unicodedata
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "app/src/main/assets/quran_full.json"
KT = ROOT / "app/src/main/java/com/noorsalat/app/QuranRepo.kt"
URL = "https://api.alquran.cloud/v1/quran/quran-uthmani"
BASMALA = "بسم الله الرحمن الرحيم"


def expected_counts():
    src = KT.read_text(encoding="utf-8")
    m = re.search(r"COUNTS\s*=\s*intArrayOf\((.*?)\)", src, re.S)
    if not m:
        raise SystemExit("لم أجد جدول COUNTS في QuranRepo.kt")
    nums = [int(x) for x in re.findall(r"\d+", m.group(1))]
    if len(nums) != 114 or sum(nums) != 6236:
        raise SystemExit("جدول COUNTS غير صحيح: %d سورة، مجموع %d" % (len(nums), sum(nums)))
    return nums


def norm(s):
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    return s.replace("ـ", "").replace("ٱ", "ا")


def strip_basmala(surah, idx, text):
    if surah in (1, 9) or idx != 0:
        return text
    words = text.split()
    if len(words) > 4 and norm(" ".join(words[:4])) == BASMALA:
        return " ".join(words[4:])
    return text


def download():
    last = None
    for attempt in range(1, 5):
        try:
            req = urllib.request.Request(URL, headers={"User-Agent": "NoorSalat-build/1.0"})
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as e:  # noqa: BLE001
            last = e
            print("محاولة %d فشلت: %s" % (attempt, e), file=sys.stderr)
            time.sleep(3 * attempt)
    raise SystemExit("تعذّر تنزيل المصحف: %s" % last)


def build(data, counts):
    surahs = data["data"]["surahs"]
    if len(surahs) != 114:
        raise SystemExit("عدد السور %d بدل 114" % len(surahs))
    out = []
    for i, s in enumerate(surahs):
        n = i + 1
        if s.get("number") != n:
            raise SystemExit("ترتيب السور غير متوقع عند %d" % n)
        ayahs = [strip_basmala(n, j, a["text"]).strip() for j, a in enumerate(s["ayahs"])]
        if len(ayahs) != counts[i]:
            raise SystemExit("سورة %d: %d آية بدل %d" % (n, len(ayahs), counts[i]))
        if any(not a for a in ayahs):
            raise SystemExit("سورة %d فيها آية فارغة" % n)
        out.append(ayahs)
    return out


def main():
    counts = expected_counts()
    data = download()
    quran = build(data, counts)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(quran, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print("تم: %d سورة، %d آية → %s (%.0f KB)" % (len(quran), sum(len(x) for x in quran), OUT, OUT.stat().st_size / 1024))


if __name__ == "__main__":
    main()
